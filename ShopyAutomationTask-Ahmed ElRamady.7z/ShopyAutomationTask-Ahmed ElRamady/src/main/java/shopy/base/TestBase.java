package shopy.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;
import shopy.pages.BraceletsPage;
import shopy.pages.CartPage;
import shopy.pages.HomePage;


public class TestBase {

	private WebDriver driver;
	protected HomePage homePage;
	protected BraceletsPage braceletsPage;
	protected CartPage cartPage;
	
	@BeforeClass
	public void setUp() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://demo.themeparrot.com/shopy/");
		driver.manage().window().maximize();
		homePage = new HomePage(driver);
	}
	
}
