package shopy.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BraceletsPage {

	private WebDriver driver;
	private By searchBar = By.name("search");
	private By goBtn = By.xpath("//form[@id='productFilters']//input[@value='Go']");
	private By searchResults = By.xpath("//div[@class='col-sm-4']");
	private By addToCartBtn = By.cssSelector("#j2store-addtocart-form-15 button");
	private By firstItemPrice = By.xpath("/html/body/div[2]/div[1]/div/div/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/span[2]");
	private By cartBtn = By.xpath("//header/div[1]/div[2]/div[2]/a[1]");
	
	public BraceletsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}
	
	public void searchInBraceletsPage(String keyWord) {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(searchBar).sendKeys(keyWord);
	}
	
	public void clickGoBtn() {
		driver.findElement(goBtn).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}
	
	public boolean validateRelativeItems(String keyWord) {
		boolean isRelative = true;
		List <WebElement> resultsList = driver.findElements(searchResults);
		for (int i = 0; i < resultsList.size(); i++) {
		    if (!resultsList.get(i).getText().toLowerCase().contains(keyWord)) {
		        isRelative = false;
		    }
		}
		
		return isRelative;
	}
	
	public String getFirstItemPrice() {
		return driver.findElement(firstItemPrice).getText();
	}
	
	public void clickAddToCart() {
		driver.findElement(addToCartBtn).click();
	}
	
	public CartPage clickOnCartIcon() {
		driver.findElement(cartBtn).click();
		return new CartPage(driver);
	}
	
	
}
