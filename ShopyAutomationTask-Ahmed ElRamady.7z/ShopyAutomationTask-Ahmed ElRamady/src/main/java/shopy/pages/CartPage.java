package shopy.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {

	private WebDriver driver;
	private By totalPrice = By.xpath("//table[@class='cart-footer table table-bordered']//tbody//tr[2]//td");
	
	public CartPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getTotalPrice() {
		return driver.findElement(totalPrice).getText();
	}
}
