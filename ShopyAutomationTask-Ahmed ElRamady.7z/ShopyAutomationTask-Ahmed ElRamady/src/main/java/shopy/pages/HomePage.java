package shopy.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HomePage {

	private WebDriver driver;
	private By catalogTab = By.xpath("//li[@data-id=\"111\"]");
	private By braceletsIcon = By.xpath("//li[@data-id=\"113\"]");
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void hoverOnCatalogTab() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement catalog = driver.findElement(catalogTab);
		Actions action = new Actions(driver);
		action.moveToElement(catalog).perform();
	}
	
	public BraceletsPage clickOnBracelets() {
		driver.findElement(braceletsIcon).click();
		return new BraceletsPage(driver);
	}
}
