package shopy.tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import shopy.base.TestBase;
import shopy.loadProperties.LoadProperties;

public class TestAddToCart extends TestBase{

	String searchWord = LoadProperties.userdata.getProperty("keyword");
	
	@Test
	public void testAddToCart() {
		homePage.hoverOnCatalogTab();
		braceletsPage = homePage.clickOnBracelets();
		braceletsPage.searchInBraceletsPage(searchWord);
		braceletsPage.clickGoBtn();
		String itemPrice = braceletsPage.getFirstItemPrice();
		braceletsPage.clickAddToCart();
		cartPage = braceletsPage.clickOnCartIcon();
		assertEquals(cartPage.getTotalPrice(), itemPrice );
		
	}
}
