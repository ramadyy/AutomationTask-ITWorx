package shopy.tests;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import shopy.base.TestBase;
import shopy.loadProperties.LoadProperties;

public class TestSuccessfullBraceletsLanding extends TestBase {

	private WebDriver driver;
	String braceletPageUrl = LoadProperties.userdata.getProperty("braceletPageUrl");
	
	@Test
	public void testBraceletsPage() {
		homePage.hoverOnCatalogTab();
		braceletsPage = homePage.clickOnBracelets();
		assertEquals(braceletsPage.getCurrentUrl(), braceletPageUrl);
	}
}
