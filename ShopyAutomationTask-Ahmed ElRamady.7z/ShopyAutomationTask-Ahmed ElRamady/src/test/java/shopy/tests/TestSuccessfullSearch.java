package shopy.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import shopy.base.TestBase;
import shopy.loadProperties.LoadProperties;

public class TestSuccessfullSearch extends TestBase{

	String keyWord = LoadProperties.userdata.getProperty("keyword");
	
	@Test
	public void testSearch() {
		homePage.hoverOnCatalogTab();
		braceletsPage = homePage.clickOnBracelets();
		braceletsPage.searchInBraceletsPage(keyWord);
		braceletsPage.clickGoBtn();
		assertTrue(braceletsPage.validateRelativeItems(keyWord));
	}
}
